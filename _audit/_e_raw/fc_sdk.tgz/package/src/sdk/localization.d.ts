/*!
 * Copyright (c) Friendly Captcha GmbH 2023.
 * This Source Code Form is subject to the terms of the Mozilla Public
 * License, v. 2.0. If a copy of the MPL was not distributed with this
 * file, You can obtain one at https://mozilla.org/MPL/2.0/.
 */
type PlaceholderLocalization = {
    title: string;
    connecting: string;
    retrying: string;
    failed: string;
    newTab: string;
};
export declare function isRTLLanguage(lang: string): boolean;
export declare function getLocalizedWidgetTitle(lang: string): string;
export declare function getLocalizedText(lang: string, type: keyof PlaceholderLocalization): string;
export {};
//# sourceMappingURL=localization.d.ts.map