/*!
 * Copyright (c) Friendly Captcha GmbH 2023.
 * This Source Code Form is subject to the terms of the Mozilla Public
 * License, v. 2.0. If a copy of the MPL was not distributed with this
 * file, You can obtain one at https://mozilla.org/MPL/2.0/.
 */
import { RiskIntelligenceErrorData } from "../types/riskIntelligence";
import { WidgetErrorData, WidgetResetTrigger, WidgetState, WidgetMode } from "../types/widget";
/**
 * `"frc:widget.statechange"`
 * @public
 */
export declare const FRCWidgetStateChangeEventName = "frc:widget.statechange";
/**
 * `"frc:widget.complete"`
 * @public
 */
export declare const FRCWidgetCompleteEventName = "frc:widget.complete";
/**
 * `"frc:widget.expire"`
 * @public
 */
export declare const FRCWidgetExpireEventName = "frc:widget.expire";
/**
 * `"frc:widget.error"`
 * @public
 */
export declare const FRCWidgetErrorEventName = "frc:widget.error";
/**
 * `"frc:widget.reset"`
 * @public
 */
export declare const FRCWidgetResetEventName = "frc:widget.reset";
/**
 * `"frc:riskintelligence.complete"`
 * @public
 */
export declare const FRCRiskIntelligenceCompleteEventName = "frc:riskintelligence.complete";
/**
 * `"frc:riskintelligence.error"`
 * @public
 */
export declare const FRCRiskIntelligenceErrorEventName = "frc:riskintelligence.error";
/**
 * `"frc:riskintelligence.expire"`
 * @public
 */
export declare const FRCRiskIntelligenceExpireEventName = "frc:riskintelligence.expire";
/**
 * A DOM event map for all events that can be dispatched by a widget.
 * @public
 */
export interface FRCEventMap {
    [FRCWidgetStateChangeEventName]: FRCWidgetStateChangeEvent;
    [FRCWidgetCompleteEventName]: FRCWidgetCompleteEvent;
    [FRCWidgetExpireEventName]: FRCWidgetWidgetExpireEvent;
    [FRCWidgetErrorEventName]: FRCWidgetWidgetErrorEvent;
    [FRCWidgetResetEventName]: FRCWidgetWidgetResetEvent;
    [FRCRiskIntelligenceCompleteEventName]: FRCRiskIntelligenceCompleteEvent;
    [FRCRiskIntelligenceErrorEventName]: FRCRiskIntelligenceErrorEvent;
    [FRCRiskIntelligenceExpireEventName]: FRCRiskIntelligenceExpireEvent;
}
/**
 * Names of any of the events that can be dispatched by a widget.
 * @public
 */
export type FRCEventName = keyof FRCEventMap;
/**
 * Payloads of any of the events that can be dispatched by a widget.
 * @public
 */
export type FRCEventData = FRCWidgetStateChangeEventData | FRCWidgetCompleteEventData | FRCWidgetExpireEventData | FRCWidgetErrorEventData | FRCWidgetResetEventData | FRCRiskIntelligenceCompleteEventData | FRCRiskIntelligenceErrorEventData | FRCRiskIntelligenceExpireEventData;
/**
 * Payload of the `"frc:widget.statechange"` event.
 * @public
 */
export interface FRCWidgetStateChangeEventData {
    /**
     * `"frc:widget.statechange"`
     */
    name: typeof FRCWidgetStateChangeEventName;
    /**
     * The new state of the widget.
     */
    state: WidgetState;
    /**
     * The current `frc-captcha-response` value.
     */
    response: string;
    /**
     * The WidgetMode returned from the API. Smart Mode intelligently chooses between
     * One-click Mode ("interactive") and Zero-click Mode ("noninteractive"). The mode is configured
     * in the Friendly Captcha dashboard.
     *
     * @remarks
     * The API chooses the mode during activation, meaning that the mode will not be available prior
     * to the `"activated"` state. In other words, `mode` will be only be present for `"activated"`,
     * `"requesting"`, `"solving"`, `"verifying"`, `"completed"`, and `"error"`. For other states, it
     * will be `undefined`. See the [widget lifecycle](../lifecycle) docs for more information.
     */
    mode?: WidgetMode;
    /**
     * The error that caused the state change, if any. Undefined if `state` is not equal to `"error"`.
     */
    error?: WidgetErrorData;
    /**
     * The widget ID that the event originated from.
     */
    id: string;
}
/**
 * Event that gets dispatched when the widget enters a new state.
 * @public
 */
export type FRCWidgetStateChangeEvent = CustomEvent<FRCWidgetStateChangeEventData>;
/**
 * Payload of the `"frc:widget.complete"` event.
 * @public
 */
export interface FRCWidgetCompleteEventData {
    /**
     * `"frc:widget.complete"`
     */
    name: typeof FRCWidgetCompleteEventName;
    state: "completed";
    /**
     * The current `frc-captcha-response` value.
     */
    response: string;
    /**
     * The widget ID that the event originated from.
     */
    id: string;
}
/**
 * Event that gets dispatched when the widget is completed. This happens when the user's browser has succesfully passed the captcha challenge.
 * @public
 */
export type FRCWidgetCompleteEvent = CustomEvent<FRCWidgetCompleteEventData>;
/**
 * Payload of the `"frc:widget.expire"` event.
 * @public
 */
export interface FRCWidgetExpireEventData {
    /**
     * `"frc:widget.expire"`
     */
    name: typeof FRCWidgetExpireEventName;
    state: "expired";
    /**
     * The current `frc-captcha-response` value.
     */
    response: string;
    /**
     * The widget ID that the event originated from.
     */
    id: string;
}
/**
 * Event that gets dispatched when the widget expires. This happens when the user takes too long to submit the captcha after it is solved.
 * @public
 */
export type FRCWidgetWidgetExpireEvent = CustomEvent<FRCWidgetExpireEventData>;
/**
 * Payload of the `"frc:widget.error"` event.
 * @public
 */
export interface FRCWidgetErrorEventData {
    /**
     * `"frc:widget.error"`
     */
    name: typeof FRCWidgetErrorEventName;
    state: "error";
    /**
     * The current `frc-captcha-response` value.
     */
    response: string;
    /**
     * The error that caused the state change.
     */
    error: WidgetErrorData;
    /**
     * The widget ID that the event originated from.
     */
    id: string;
}
/**
 * Event that gets dispatched when something goes wrong in the widget.
 * @public
 */
export type FRCWidgetWidgetErrorEvent = CustomEvent<FRCWidgetErrorEventData>;
/**
 * Payload of the `"frc:widget.reset"` event.
 * @public
 */
export interface FRCWidgetResetEventData {
    /**
     * `"frc:widget.reset"`
     */
    name: typeof FRCWidgetResetEventName;
    state: "reset";
    /**
     * The current `frc-captcha-response` value.
     */
    response: string;
    /**
     * What caused the reset. Possible values:
     * * `"widget"`: reset initiated by the widget (`"widget"`), which generally means the user clicked the reset button within the widget.
     * * `"root"`: triggered by your own code on the current page (by calling `widget.reset()`).
     * * `"agent"`: triggered by the background agent (currently never happens).
     */
    trigger: WidgetResetTrigger;
    /**
     * The widget ID that the event originated from.
     */
    id: string;
}
/**
 * Event that gets dispatched when something goes wrong in the widget.
 * @public
 */
export type FRCWidgetWidgetResetEvent = CustomEvent<FRCWidgetResetEventData>;
/**
 * Payload of the `"frc:riskintelligence.complete"` event.
 * @public
 */
export interface FRCRiskIntelligenceCompleteEventData {
    /**
     * `"frc:riskintelligence.complete"`
     */
    name: typeof FRCRiskIntelligenceCompleteEventName;
    /**
     * The Risk Intelligence response token, to be verified server-side.
     */
    token: string;
    /**
     * A timestamp, represented as a Unix epoch, for when the Risk Intelligence token will expire.
     */
    expiresAt: number;
}
/**
 * Event that gets dispatched when a Risk Intelligence token has been successfully generated.
 * @public
 */
export type FRCRiskIntelligenceCompleteEvent = CustomEvent<FRCRiskIntelligenceCompleteEventData>;
/**
 * Payload of the `"frc:riskintelligence.error"` event.
 * @public
 */
export interface FRCRiskIntelligenceErrorEventData {
    /**
     * `"frc:riskintelligence.error"`
     */
    name: typeof FRCRiskIntelligenceErrorEventName;
    /**
     * The error that occurred.
     */
    error: RiskIntelligenceErrorData;
}
/**
 * Event that gets dispatched when the Risk Intelligence request fails.
 * @public
 */
export type FRCRiskIntelligenceErrorEvent = CustomEvent<FRCRiskIntelligenceErrorEventData>;
/**
 * Payload of the `"frc:riskintelligence.expire"` event.
 * @public
 */
export interface FRCRiskIntelligenceExpireEventData {
    /**
     * `"frc:riskintelligence.expire"`
     */
    name: typeof FRCRiskIntelligenceExpireEventName;
}
/**
 * Event that gets dispatched when a Risk Intelligence token expires.
 * @public
 */
export type FRCRiskIntelligenceExpireEvent = CustomEvent<FRCRiskIntelligenceExpireEventData>;
//# sourceMappingURL=events.d.ts.map